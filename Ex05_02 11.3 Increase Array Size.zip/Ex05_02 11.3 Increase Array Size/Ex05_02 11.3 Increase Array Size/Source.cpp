
////////////////
// Tersa Almaw
// Ex05_11.3 Increase array size
//
//

#include <iostream>
using namespace std;

// part 1: Analyze input

void prompt_count(int* size)
{
	cout << "what is the amount of numbers you will enter? "; // asks the user to input the size of the amount of numbers they'll enter.
	cin >> *size;
}
void populate_numbers(int* numbers, int size) {
	for (int*current = numbers; current < numbers + size; current++) {
		cout << "Enter number: "; // prompts the user to enter a number
		cin >> *current; // displays *current
	}
}
int *alloc_array(int size)
{
	int* pointarray = new int[size];
	for (int i = 0; i < size; i++) // i= 0 and it goes up to size
	{
		cout << "Enter a number";
		cin >> pointarray[i];
	} // change this number to the pouplate_number

	return pointarray; //returns pointarray
}

double computeAverage(int numbers[], int size) {
	double average = 0; // average is zero
	double sum = 0;
	for (int* current = numbers; current < numbers + size; current++)
	{
		sum += *current;
	}
	average = sum / size; // the avreage = sum divided by the size
	return average; // return average
}

int computeAbove(int number[], int size)
{
	int numAbove = 0; // initialize numAbove to be zero

	double average = computeAverage(number, size);
	for (int* current = number; current < number + size; current++) // current stars at number and then it goes until number+ size
	{
		if (*current > average) //current number is above the average then
		{
			numAbove++; // the number above increments
		}
		cout << "numAbove " << numAbove; // displays the number above the average
	}
	return numAbove;
}

// part 2: 11.3 Increase in array size
int* doubleCapacity(int * list, int size)
{
	// if the inputs are invalid / negative return null immediately
	if (size <= 0) return NULL; // size cannot be zero or negative number
	if (list == NULL) return NULL;// if it is an empty then it will return 0 definition of NULL = 0
	int  newSize = 2 * size; // new array that doubles the size of the perameters
	int* newArray = new int[newSize];// create a new dynamic array with the new double size
									 // fill the contents of the old array into the new array
	for (int i = 0; i < size; i++) {
		newArray[i] = list[i]; //when list changes, i changes.
	}
	// return the new array. newArray is a pointer to an integer
	return newArray;
}

// part 3 Finds the smallest element
double findMin(double *list, double size)
{
	double smallestElement = list[0]; // assuming the list starts with a minumum which is 0

	for (int x = 1; x < size; x++)
	{
		if (list[x] < smallestElement) // is the values of list is smaller that the smallestelement
		{
			smallestElement = list[x];// equal the smallest element to be new list
		}
	}

	return smallestElement; // returns smallest element
}

int main()
{
	int nums;
	prompt_count(&nums);
	int* numbers = alloc_array(nums);
	populate_numbers(numbers, nums);
	cout << "The average of the numbers you gave me is: " << computeAverage(numbers, nums) << " Average\n";
	cout << "the numbers above the number " << computeAbove(numbers, nums);
	delete[] numbers;
	// part 2 11.3 // just checking if my code works

	//int list[4] = { 1, 2, 3, 4 };
	//int * newList = doubleCapacity(list, 4);

	//for (int i = 0; i < 8; i++)
	//{
	//    cout << newList[i] << '\t';
	//}

	// part 3 11.5

	double values[8] = { 1,2,4,5,10,100,2,-22 };

	cout << findMin(values, 8); // displayes the smallest



}
