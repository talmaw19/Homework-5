
#ifndef Rectangle2D_h
#define Rectangle2D_h



class Rectangle2D
{
private:
	double width; // width of rectangle
	double height; // height of rectangle
	double x; // x-coordinate for the center of the rectangle
	double y; // y- coordinate for the center of the rectangle

public:
	Rectangle2D(); // defalt consturctor
	Rectangle2D(double, double, double, double); // constructor that prompts for all values


	const double getX(); // returns the x coordinate
	const double getY(); // returns the y coordinate
	const double getWidth(); // returns the width
	const double getHeight(); // returns the heigh
	const void setX(double); // sets the x coordinate
	const void setY(double); // sets the y coordinate
	const void setWidth(double); // sets the width of the rectangle
	const void setHeight(double); // sets the height of the rectangle
	const double getArea(); // calculates and then return area of rectangle
	const double getPerimeter(); // calculates and then return the perimeter of rectangle
	const bool contains(double, double);
	const bool contains(const Rectangle2D &r);
	const bool overlaps(const Rectangle2D &r);




};


#endif /* Rectangle2D_h */