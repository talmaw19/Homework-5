
#include "Rectangle2D.h"

Rectangle2D::Rectangle2D() // default constructor
{
	x = 0; // rectangles default coordinates
	y = 0; // rectangles default coordinates
	width = 1; // rectangles default width
	height = 1; // rectangles default heigh
}
Rectangle2D::Rectangle2D(double xInput, double yInput, double widthInput, double heightInput)
{
	// sets x, y, width, heightto the value passed to the function
	x = xInput;
	y = yInput;
	width = widthInput;
	height = heightInput;
}


const double Rectangle2D::getX() // returns x
{
	return x;
}
const double Rectangle2D::getY() // returns y
{
	return y;
}
const double Rectangle2D::getHeight() // returns height
{
	return height;
}
const double Rectangle2D::getWidth() // return width
{
	return width;
}
const void Rectangle2D::setX(double newX) // sets the old x coordinate to a new x
{
	x = newX;
}
const void Rectangle2D::setY(double newY)// sets the old y coordinate to a new y
{
	y = newY;
}

const void Rectangle2D::setWidth(double newWidth) // sets the old width to the newWidth
{
	width = newWidth();
}
const void Rectangle2D::setHeight(double newHeight)// sets the old heigh to the new height
{
	height = newHeight;
}
const double Rectangle2D::getArea() // calculates the area of the rectangle then returns the area
{
	double area = height* width;
	return area;
}
const double Rectangle2D::getPerimeter()// calculates the perimeter of the rectangle then returns the perimeter
{
	double perimeter = 2 * (height + width);
	return perimeter;
}
const bool Rectangle2D::contains(double pointerX, double pointerY)
{
	bool contains = false; // contain is false is the
}

const bool Rectangle2D::contains(double pointerX, double pointerY)
{
	bool contains = false;
	if ((pointerX <= ((width / 2) + x) && (pointerX >= ((-width / 2) + x))) && ((pointerY <= ((height / 2) + y)) && (pointerY >= ((-height / 2) + y))))
		contains = true; // if the point is within the rectangle, then the function sets contains it to be true.
	return contains; // returns contains
}

const bool Rectangle2D::contains(const Rectangle2D &r)
{
	bool contains = false;
	if ((((r.width / 2) + r.x) <= ((width / 2) + x)) && (((-r.width / 2) + r.x) >= ((-width / 2) + x)) && (((r.height / 2) + r.x) <= ((height / 2) + x)) && (((-r.height / 2) + r.x) >= ((-height / 2) + x)))
		contains = true;
	return contains;
}

const bool Rectangle2D::overlaps(const Rectangle2D &r)
{
	bool overlap;
	if ((((r.width / 2) + r.x) <= ((width / 2) + x)) || (((-r.width / 2) + r.x) >= ((-width / 2) + x)) || (((r.height / 2) + r.x) <= ((height / 2) + x)) || (((-r.height / 2) + r.x) >= ((-height / 2) + x)))
		overlap = true;
	return overlap;
}
